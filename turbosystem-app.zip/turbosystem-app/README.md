# TURBOSYSTEM — Szkolenie: Silniki Turbinowe

Kompletna aplikacja webowa (PWA) do szkolenia mechaników lotniczych z zakresu budowy
i systemów silnika turbinowego. Czysty HTML5 / CSS3 / Vanilla JavaScript (ES6+) —
bez frameworków.

## Jak uruchomić

Aplikacja pobiera dane (`data/*.json`) przez `fetch()`, dlatego **musi być serwowana
przez lokalny serwer HTTP** (otwarcie `index.html` bezpośrednio jako plik `file://`
zablokuje fetch ze względów bezpieczeństwa przeglądarki).

Najprościej:

```bash
cd turbosystem-app
python -m http.server 8080
# lub
npx serve .
```

Następnie otwórz `http://localhost:8080` w przeglądarce (najlepiej w widoku mobilnym
DevTools — aplikacja jest zaprojektowana mobile-first).

## Struktura projektu

```
turbosystem-app/
├── index.html              powłoka aplikacji (wszystkie ekrany SPA)
├── manifest.json            manifest PWA
├── sw.js                    service worker (cache offline)
├── css/
│   └── style.css            pełny design system (tokeny, komponenty)
├── js/
│   ├── storage.js           localStorage + eksport wyników JSON
│   ├── navigation.js        przełączanie ekranów, ripple, toast
│   ├── animations.js        generatory animowanych diagramów SVG
│   ├── quiz.js               silnik quizu (losowanie, ocenianie, bramka 75%)
│   └── app.js                bootstrap, dashboard, rozdziały, słownik, statystyki
├── data/
│   ├── chapters.json         treści wszystkich 5 rozdziałów / 19 tematów
│   ├── questions.json        bank pytań quizowych (15 pytań / rozdział = 75 pytań)
│   └── glossary.json         słownik pojęć (30 haseł)
└── assets/icons/              ikony PWA (SVG)
```

## Zakres merytoryczny

5 rozdziałów zgodnie ze specyfikacją:

1. **Wprowadzenie** — zasada działania i powstawanie ciągu
2. **Zimna sekcja** — wlot, wentylator, kompresor
3. **Gorąca sekcja** — komora spalania, turbina, wydech
4. **Stany niesprawności** — stall, surge, vibrations, ice, burn, creep, oil leaks
5. **Systemy silnika** — oil, fuel, start, ignition, FADEC

Każdy temat zawiera 7 sekcji: Jak działa / Budowa / Materiały / Najczęstsze uszkodzenia /
Ciekawostki / Najważniejsze informacje / Podsumowanie — plus animowany diagram SVG i fiszkę.

## Uwaga dot. skali banku pytań

Zgodnie z pierwotną specyfikacją docelowo każdy rozdział powinien mieć 30 pytań
(150 łącznie). W tej wersji dostarczono **15 starannie opracowanych pytań na rozdział
(75 łącznie)** jako solidną, w pełni funkcjonalną bazę — silnik quizu (`quiz.js`) losuje
kolejność pytań i odpowiedzi z całej dostępnej puli, więc rozszerzenie banku do 30 pytań
wymaga jedynie dopisania kolejnych obiektów do `data/questions.json` w tym samym schemacie —
bez zmian w kodzie.

## Odblokowywanie rozdziałów

Próg zaliczenia quizu: **75%**. Po jego przekroczeniu automatycznie odblokowuje się
kolejny rozdział (`storage.js → unlockNextChapter`). Poniżej progu wyświetlany jest
komunikat: *"Minimalny wynik to 75%. Powtórz quiz aby odblokować następny rozdział."*

## Zapis wyników

Każde podejście do quizu zapisywane jest w `localStorage` w formacie zgodnym ze
specyfikacją (`date`, `time`, `chapter`, `mode`, `name`, `score`, ...). Przycisk
**"Eksportuj wyniki (JSON)"** w zakładce Statystyki pobiera plik `.json` gotowy do
podłączenia backendu.

## Dalsza rozbudowa

- Rozszerzenie banku pytań do 30/rozdział — edycja `data/questions.json`
- Podłączenie backendu — podmiana funkcji w `storage.js` na wywołania REST/GraphQL
  (interfejs funkcji został zaprojektowany pod kątem takiej migracji)
- Dodatkowe animacje SVG — kolejne wpisy w `TOPIC_DIAGRAM_MAP` w `animations.js`
