/* ============================================================
   QUIZ.JS
   Silnik quizu: losowanie kolejności pytań i odpowiedzi,
   walidacja trybu indywidualnego/grupowego, ocenianie,
   bramka 75% do odblokowania kolejnego rozdziału,
   zapis wyniku do Storage w formacie zgodnym ze specyfikacją JSON.
============================================================ */

const Quiz = {
  chapterId: null,
  mode: 'individual',
  participantName: '',
  questions: [],
  current: 0,
  correctCount: 0,
  answered: false,
  startTime: null,
  mistakes: [], // {q, yourAnswer, correctAnswer, explain}

  /* Wybór trybu z ekranu ustawień quizu */
  selectMode(mode){
    this.mode = mode;
    document.getElementById('mode-individual').classList.toggle('selected', mode === 'individual');
    document.getElementById('mode-group').classList.toggle('selected', mode === 'group');
    document.getElementById('name-field').classList.toggle('show', mode === 'individual');
    document.getElementById('field-error').classList.remove('show');
  },

  /* Otwiera ekran wyboru trybu dla danego rozdziału */
  openSetup(chapterId){
    this.chapterId = chapterId;
    const chapter = CHAPTERS_DATA.chapters.find(c => c.id === chapterId);
    document.getElementById('quiz-setup-chapter').textContent = `Rozdział ${chapterId} // ${chapter.title}`;
    this.selectMode('individual');
    document.getElementById('participant-name').value = '';
    Navigation.goTo('quiz-setup');
  },

  /* Rozpoczyna quiz po walidacji formularza */
  begin(){
    if(this.mode === 'individual'){
      const nameInput = document.getElementById('participant-name');
      const name = nameInput.value.trim();
      if(!name){
        document.getElementById('field-error').classList.add('show');
        nameInput.focus();
        return;
      }
      this.participantName = name;
    } else {
      this.participantName = '';
    }

    const bank = (QUESTIONS_DATA.questions[String(this.chapterId)] || []).slice();
    this.questions = shuffleArray(bank).map(q => {
      // przetasuj też kolejność odpowiedzi, zachowując poprawny indeks
      const order = shuffleArray(q.answers.map((a,i)=>i));
      const answers = order.map(i => q.answers[i]);
      const correct = order.indexOf(q.correct);
      return { q: q.q, answers, correct, explain: q.explain };
    });

    this.current = 0;
    this.correctCount = 0;
    this.mistakes = [];
    this.startTime = Date.now();

    this.buildProgressTrack();
    this.renderQuestion();
    Navigation.goTo('quiz-run');
  },

  buildProgressTrack(){
    const track = document.getElementById('quiz-progress-track');
    track.innerHTML = this.questions.map((_,i)=>`<div class="quiz-progress-fill-seg" data-i="${i}"></div>`).join('');
  },

  renderQuestion(){
    const idx = this.current;
    const item = this.questions[idx];
    this.answered = false;

    document.getElementById('quiz-counter').textContent = `${idx+1} / ${this.questions.length}`;
    document.getElementById('q-text').textContent = item.q;
    document.getElementById('explain-box').classList.remove('show');

    document.querySelectorAll('.quiz-progress-fill-seg').forEach((seg,i)=>{
      seg.classList.toggle('lit', i < idx);
    });

    const letters = ['A','B','C','D'];
    document.getElementById('answers-wrap').innerHTML = item.answers.map((a,i)=>`
      <button class="answer-opt" data-i="${i}" onclick="Quiz.selectAnswer(${i})">
        <span class="letter">${letters[i]}</span><span>${escapeHtml(a)}</span>
      </button>
    `).join('');
    document.getElementById('next-q-btn').classList.remove('show');
  },

  selectAnswer(i){
    if(this.answered) return;
    this.answered = true;
    const item = this.questions[this.current];
    const opts = document.querySelectorAll('.answer-opt');
    opts.forEach((o, idx) => {
      o.style.pointerEvents = 'none';
      if(idx === item.correct) o.classList.add('correct');
      else if(idx === i) o.classList.add('wrong');
    });

    const explainBox = document.getElementById('explain-box');
    explainBox.textContent = item.explain;
    explainBox.classList.add('show');

    if(i === item.correct){
      this.correctCount++;
    } else {
      this.mistakes.push({
        q: item.q,
        yourAnswer: item.answers[i],
        correctAnswer: item.answers[item.correct],
        explain: item.explain
      });
    }

    const nextBtn = document.getElementById('next-q-btn');
    nextBtn.classList.add('show');
    nextBtn.textContent = this.current === this.questions.length - 1 ? 'Zobacz wynik' : 'Następne pytanie';
  },

  next(){
    this.current++;
    if(this.current >= this.questions.length){
      this.finish();
      return;
    }
    this.renderQuestion();
  },

  finish(){
    document.querySelectorAll('.quiz-progress-fill-seg').forEach(seg => seg.classList.add('lit'));
    const total = this.questions.length;
    const pct = Math.round((this.correctCount / total) * 100);
    const passed = pct >= 75;
    const durationSec = Math.round((Date.now() - this.startTime) / 1000);

    // zapis wyniku w formacie zgodnym ze specyfikacją
    const now = new Date();
    const entry = {
      date: now.toISOString().slice(0,10),
      time: now.toTimeString().slice(0,5),
      chapter: this.chapterId,
      mode: this.mode,
      name: this.participantName,
      score: pct,
      correct: this.correctCount,
      total: total,
      durationSec: durationSec,
      mistakes: this.mistakes.map(m => m.q)
    };
    Storage.addResult(entry);
    Storage.addStudySeconds(durationSec);

    let progress = Storage.updateChapterProgress(this.chapterId, {
      pct: Math.max(pct, (Storage.getProgress()[this.chapterId]||{}).pct || 0),
      bestScore: Math.max(pct, (Storage.getProgress()[this.chapterId]||{}).bestScore || 0),
      status: passed ? 'completed' : 'unlocked'
    });
    if(passed){
      progress = Storage.unlockNextChapter(this.chapterId);
    }

    this.renderResult(pct, passed, durationSec);
    Navigation.goTo('quiz-result');
  },

  renderResult(pct, passed, durationSec){
    const ring = document.getElementById('result-ring');
    const circumference = 389.5;
    const offset = circumference - (circumference * pct / 100);
    ring.style.stroke = passed ? '#3ecf8e' : '#ff5252';
    ring.style.strokeDashoffset = circumference;
    document.getElementById('result-pct-text').textContent = pct + '%';

    setTimeout(() => {
      ring.style.transition = 'stroke-dashoffset 1.1s cubic-bezier(.2,.8,.2,1)';
      ring.style.strokeDashoffset = offset;
    }, 100);

    const mm = String(Math.floor(durationSec/60)).padStart(2,'0');
    const ss = String(durationSec%60).padStart(2,'0');

    document.getElementById('result-correct').textContent = `${this.correctCount}/${this.questions.length}`;
    document.getElementById('result-time').textContent = `${mm}:${ss}`;
    document.getElementById('result-errors').textContent = this.mistakes.length;

    const gateBox = document.getElementById('gate-message');
    if(passed){
      gateBox.classList.add('pass');
      gateBox.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>
        <span>Świetna robota! Wynik ${pct}% — kolejny rozdział został odblokowany.</span>`;
    } else {
      gateBox.classList.remove('pass');
      gateBox.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>
        <span>Minimalny wynik to 75%. Powtórz quiz aby odblokować następny rozdział.</span>`;
    }

    const reviewList = document.getElementById('review-list');
    if(this.mistakes.length === 0){
      reviewList.innerHTML = `<p class="lead" style="text-align:center;">Brak błędnych odpowiedzi — komplet punktów!</p>`;
    } else {
      reviewList.innerHTML = this.mistakes.map(m => `
        <div class="review-item">
          <div class="rq">${escapeHtml(m.q)}</div>
          <div class="ra">Twoja odpowiedź: ${escapeHtml(m.yourAnswer)}. <strong>Poprawna: ${escapeHtml(m.correctAnswer)}</strong> — ${escapeHtml(m.explain)}</div>
        </div>
      `).join('');
    }
  }
};

/* ---------- utils ---------- */
function shuffleArray(arr){
  const a = arr.slice();
  for(let i = a.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i+1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
