/* ============================================================
   STORAGE.JS
   Warstwa dostępu do danych trwałych (localStorage).
   Zaprojektowana tak, by łatwo podmienić localStorage
   na wywołania do backendu (REST/GraphQL) w przyszłości —
   każda funkcja zwraca Promise, mimo że dziś operuje synchronicznie.
============================================================ */

const STORAGE_KEYS = {
  PROGRESS: 'turbosystem_progress',      // ukończone rozdziały, % postępu
  RESULTS: 'turbosystem_results',        // tablica JSON z wynikami quizów
  SETTINGS: 'turbosystem_settings',      // dark mode, dźwięk, itd.
  LAST_SCREEN: 'turbosystem_last_screen',
  STUDY_TIME: 'turbosystem_study_seconds'
};

const Storage = {

  /* ---------- PROGRESS ---------- */
  getProgress(){
    const raw = localStorage.getItem(STORAGE_KEYS.PROGRESS);
    if(raw) return JSON.parse(raw);
    // domyślny stan startowy — rozdział 1 odblokowany, reszta zablokowana
    const initial = {};
    CHAPTERS_DATA.chapters.forEach((ch, i) => {
      initial[ch.id] = { status: i === 0 ? 'unlocked' : 'locked', pct: 0, bestScore: null };
    });
    return initial;
  },
  saveProgress(progress){
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(progress));
  },
  updateChapterProgress(chapterId, patch){
    const progress = this.getProgress();
    progress[chapterId] = { ...progress[chapterId], ...patch };
    this.saveProgress(progress);
    return progress;
  },
  unlockNextChapter(currentChapterId){
    const progress = this.getProgress();
    const nextId = currentChapterId + 1;
    if(progress[nextId] && progress[nextId].status === 'locked'){
      progress[nextId].status = 'unlocked';
      this.saveProgress(progress);
    }
    return progress;
  },

  /* ---------- RESULTS (format zgodny ze specyfikacją JSON) ---------- */
  getResults(){
    const raw = localStorage.getItem(STORAGE_KEYS.RESULTS);
    return raw ? JSON.parse(raw) : [];
  },
  addResult(entry){
    // entry: {date, time, chapter, mode, name, score, correct, total, durationSec}
    const results = this.getResults();
    results.push(entry);
    localStorage.setItem(STORAGE_KEYS.RESULTS, JSON.stringify(results));
    return results;
  },
  exportResultsAsFile(){
    const results = this.getResults();
    const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turbosystem-wyniki-${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  /* ---------- SETTINGS ---------- */
  getSettings(){
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? JSON.parse(raw) : { darkMode: true, sound: true, offline: true };
  },
  saveSettings(settings){
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },

  /* ---------- NAVIGATION MEMORY ---------- */
  getLastScreen(){
    return localStorage.getItem(STORAGE_KEYS.LAST_SCREEN) || 'dashboard';
  },
  saveLastScreen(screenId){
    localStorage.setItem(STORAGE_KEYS.LAST_SCREEN, screenId);
  },

  /* ---------- STUDY TIME ---------- */
  getStudySeconds(){
    return parseInt(localStorage.getItem(STORAGE_KEYS.STUDY_TIME) || '0', 10);
  },
  addStudySeconds(sec){
    const total = this.getStudySeconds() + sec;
    localStorage.setItem(STORAGE_KEYS.STUDY_TIME, String(total));
    return total;
  },

  /* ---------- RESET ---------- */
  resetAll(){
    Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
  },

  /* ---------- DERIVED STATS ---------- */
  computeStats(){
    const results = this.getResults();
    if(results.length === 0){
      return { best:0, avg:0, count:0, hardestChapter:null, mistakeFreq:{} };
    }
    const best = Math.max(...results.map(r => r.score));
    const avg = Math.round(results.reduce((s,r)=>s+r.score,0) / results.length);
    // najtrudniejszy rozdział = najniższa średnia wyniku wśród rozdziałów z >=1 podejściem
    const byChapter = {};
    results.forEach(r => {
      if(!byChapter[r.chapter]) byChapter[r.chapter] = [];
      byChapter[r.chapter].push(r.score);
    });
    let hardestChapter = null, hardestAvg = 101;
    Object.entries(byChapter).forEach(([ch, scores]) => {
      const a = scores.reduce((s,v)=>s+v,0) / scores.length;
      if(a < hardestAvg){ hardestAvg = a; hardestChapter = parseInt(ch,10); }
    });
    // agregacja błędów (jeśli dostępne w wynikach)
    const mistakeFreq = {};
    results.forEach(r => {
      (r.mistakes || []).forEach(m => {
        mistakeFreq[m] = (mistakeFreq[m] || 0) + 1;
      });
    });
    return { best, avg, count: results.length, hardestChapter, mistakeFreq, byChapter };
  }
};
