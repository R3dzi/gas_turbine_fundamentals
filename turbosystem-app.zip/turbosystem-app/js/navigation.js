/* ============================================================
   NAVIGATION.JS
   Zarządzanie przełączaniem ekranów (SPA), zapamiętywaniem
   ostatniego ekranu oraz efektem ripple na elementach klikalnych.
============================================================ */

const Navigation = {
  current: 'dashboard',

  goTo(target, opts = {}){
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById('screen-' + target);
    if(!el) return;
    el.classList.add('active');
    this.current = target;

    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navBtn = document.querySelector(`.nav-item[data-target="${target}"]`);
    if(navBtn) navBtn.classList.add('active');

    if(!opts.silent) Storage.saveLastScreen(target);
    window.scrollTo({ top:0, behavior:'instant' in window ? 'instant' : 'auto' });

    // hooks per-screen (odśwież dane przy wejściu)
    if(typeof App !== 'undefined' && CHAPTERS_DATA){
      if(target === 'dashboard') App.renderDashboard();
      if(target === 'chapters') App.renderChaptersScreen();
      if(target === 'stats') App.renderStats();
    }
  },

  init(){
    document.querySelectorAll('.nav-item[data-target]').forEach(btn => {
      btn.addEventListener('click', () => this.goTo(btn.dataset.target));
    });
    this.attachRipple();
  },

  attachRipple(){
    document.addEventListener('click', (e) => {
      const target = e.target.closest('.continue-btn, .btn-primary, .btn-secondary, .nav-item, .ch-card, .mode-opt, .answer-opt, .stat-tile');
      if(!target) return;
      const rect = target.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      const size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size/2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size/2) + 'px';
      const prevPosition = getComputedStyle(target).position;
      if(prevPosition === 'static') target.style.position = 'relative';
      target.style.overflow = target.style.overflow || 'hidden';
      target.appendChild(ripple);
      setTimeout(() => ripple.remove(), 550);
    });
  }
};

/* ============================================================
   TOAST — krótkie powiadomienia
============================================================ */
function showToast(message, duration = 2200){
  let toast = document.getElementById('global-toast');
  if(!toast){
    toast = document.createElement('div');
    toast.id = 'global-toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), duration);
}
