/* ============================================================
   ANIMATIONS.JS
   Generatory animowanych diagramów SVG dla poszczególnych tematów.
   Każda funkcja zwraca gotowy znacznik <svg> jako string.
   Diagramy są celowo uproszczone (schematyczne), zgodnie z konwencją
   dokumentacji technicznej lotnictwa (AMM-style line drawings).
============================================================ */

const Diagrams = {

  /* Przepływ powietrza przez wlot/wentylator/kompresor */
  airflow(){
    return `
    <svg width="230" height="150" viewBox="0 0 230 150">
      <rect x="10" y="45" width="210" height="60" rx="10" fill="none" stroke="#333a44" stroke-width="1.5"/>
      <line class="flow-line" x1="20" y1="60" x2="200" y2="60" stroke="#3f9eff" stroke-width="2"/>
      <line class="flow-line" x1="20" y1="75" x2="200" y2="75" stroke="#3f9eff" stroke-width="2"/>
      <line class="flow-line" x1="20" y1="90" x2="200" y2="90" stroke="#3f9eff" stroke-width="2"/>
      <path d="M195 55 L210 60 L195 65 Z" fill="#3f9eff"/>
      <path d="M195 70 L210 75 L195 80 Z" fill="#3f9eff"/>
      <path d="M195 85 L210 90 L195 95 Z" fill="#3f9eff"/>
      <text x="115" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">PRZEPŁYW POWIETRZA — WLOT</text>
    </svg>`;
  },

  /* Wirujące łopatki wentylatora/kompresora */
  rotorSpin(label){
    return `
    <svg width="200" height="150" viewBox="0 0 200 150">
      <circle cx="100" cy="70" r="46" fill="none" stroke="#333a44" stroke-dasharray="3 3"/>
      <g class="rotor-group" transform-origin="100 70">
        ${[0,60,120,180,240,300].map(a=>`<rect x="97" y="26" width="6" height="40" rx="3" fill="#2e3540" stroke="#3f9eff" stroke-width="1" transform="rotate(${a} 100 70)"/>`).join('')}
      </g>
      <circle cx="100" cy="70" r="10" fill="#242a32" stroke="#7c8590"/>
      <text x="100" y="135" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">${label}</text>
    </svg>`;
  },

  /* Powstawanie ciągu — strzałki przed/po */
  thrust(){
    return `
    <svg width="230" height="150" viewBox="0 0 230 150">
      <rect x="70" y="55" width="90" height="40" rx="8" fill="#242a32" stroke="#333a44"/>
      <text x="115" y="80" text-anchor="middle" fill="#c3c9d1" font-family="Rajdhani" font-weight="700" font-size="12">SILNIK</text>
      <line class="flow-line" x1="10" y1="75" x2="65" y2="75" stroke="#7c8590" stroke-width="2"/>
      <path d="M60 70 L72 75 L60 80 Z" fill="#7c8590"/>
      <line class="flow-line" x1="165" y1="75" x2="220" y2="75" stroke="#ff6a1f" stroke-width="3"/>
      <path d="M212 68 L226 75 L212 82 Z" fill="#ff6a1f"/>
      <text x="35" y="45" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="8">V wlot</text>
      <text x="195" y="45" text-anchor="middle" fill="#ff6a1f" font-family="JetBrains Mono" font-size="8">V wylot (większe)</text>
      <text x="115" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">F = ṁ (V wylot − V wlot)</text>
    </svg>`;
  },

  /* Komora spalania — płomień pulsujący */
  combustion(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <rect x="20" y="30" width="180" height="70" rx="30" fill="none" stroke="#333a44" stroke-width="1.5"/>
      <g>
        <ellipse class="spark-glow" cx="70" cy="65" rx="18" ry="24" fill="#ff6a1f" opacity="0.7"/>
        <ellipse class="spark-bolt" cx="70" cy="65" rx="10" ry="16" fill="#ffc636"/>
        <ellipse class="spark-glow" cx="110" cy="65" rx="18" ry="24" fill="#ff6a1f" opacity="0.7"/>
        <ellipse class="spark-bolt" cx="110" cy="65" rx="10" ry="16" fill="#ffc636"/>
        <ellipse class="spark-glow" cx="150" cy="65" rx="18" ry="24" fill="#ff6a1f" opacity="0.7"/>
        <ellipse class="spark-bolt" cx="150" cy="65" rx="10" ry="16" fill="#ffc636"/>
      </g>
      <text x="110" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">SPALANIE — KOMORA PIERŚCIENIOWA</text>
    </svg>`;
  },

  /* Świeca zapłonowa z iskrą */
  ignition(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <rect class="chamber-wall" x="15" y="20" width="190" height="110" rx="12"/>
      <rect class="igniter-body" x="95" y="8" width="30" height="46" rx="4"/>
      <line x1="110" y1="54" x2="110" y2="72" stroke="#7c8590" stroke-width="2"/>
      <circle class="spark-glow" cx="110" cy="80" r="16" fill="#ffc636"/>
      <path class="spark-bolt" d="M104 68 L114 80 L106 80 L116 96 L100 82 L108 82 Z" fill="#ffc636"/>
      <text x="110" y="140" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">HIGH ENERGY IGNITER</text>
    </svg>`;
  },

  /* Przepływ oleju w obiegu zamkniętym */
  oilFlow(){
    return `
    <svg width="230" height="150" viewBox="0 0 230 150">
      <rect x="20" y="20" width="50" height="30" rx="4" fill="#242a32" stroke="#333a44"/>
      <text x="45" y="39" text-anchor="middle" fill="#c3c9d1" font-family="Rajdhani" font-size="9" font-weight="700">ZBIORNIK</text>
      <rect x="160" y="20" width="50" height="30" rx="4" fill="#242a32" stroke="#333a44"/>
      <text x="185" y="39" text-anchor="middle" fill="#c3c9d1" font-family="Rajdhani" font-size="9" font-weight="700">ŁOŻYSKA</text>
      <path class="flow-line" d="M70 35 H160" stroke="#ffc636" stroke-width="2" fill="none"/>
      <path d="M152 30 L164 35 L152 40 Z" fill="#ffc636"/>
      <path class="flow-line" d="M185 50 V90 H45 V50" stroke="#7c8590" stroke-width="2" fill="none"/>
      <path d="M50 58 L45 46 L40 58 Z" fill="#7c8590"/>
      <text x="115" y="115" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">OBIEG OLEJU — TŁOCZENIE / ZGARNIANIE</text>
    </svg>`;
  },

  /* Przepływ paliwa do dysz wtryskowych */
  fuelFlow(){
    return `
    <svg width="230" height="150" viewBox="0 0 230 150">
      <rect x="15" y="55" width="40" height="24" rx="3" fill="#242a32" stroke="#333a44"/>
      <text x="35" y="71" text-anchor="middle" fill="#c3c9d1" font-family="Rajdhani" font-size="8">ZBIORNIK</text>
      <rect x="90" y="55" width="40" height="24" rx="3" fill="#242a32" stroke="#333a44"/>
      <text x="110" y="71" text-anchor="middle" fill="#c3c9d1" font-family="Rajdhani" font-size="8">FMU</text>
      <g>
        <circle cx="200" cy="50" r="4" fill="#3ecf8e"/>
        <circle cx="200" cy="67" r="4" fill="#3ecf8e"/>
        <circle cx="200" cy="84" r="4" fill="#3ecf8e"/>
      </g>
      <path class="flow-line" d="M55 67 H90" stroke="#3ecf8e" stroke-width="2" fill="none"/>
      <path class="flow-line" d="M130 67 H196" stroke="#3ecf8e" stroke-width="2" fill="none"/>
      <text x="115" y="120" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">DAWKOWANIE PALIWA DO DYSZ WTRYSKOWYCH</text>
    </svg>`;
  },

  /* Otwieranie zaworu upustu (bleed valve) */
  bleedValve(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <rect x="10" y="60" width="200" height="20" fill="none" stroke="#333a44" stroke-width="1.5"/>
      <g class="spark-bolt">
        <rect x="95" y="20" width="30" height="40" fill="#242a32" stroke="#ffc636" stroke-width="1.5"/>
        <path d="M100 60 L100 90" stroke="#ffc636" stroke-width="2" stroke-dasharray="4 3"/>
        <path d="M120 60 L120 90" stroke="#ffc636" stroke-width="2" stroke-dasharray="4 3"/>
      </g>
      <text x="110" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">ZAWÓR UPUSTU — CYKLICZNE OTWARCIE</text>
    </svg>`;
  },

  /* VSV — zmienny kąt łopatek kierujących */
  vsv(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <g class="spark-bolt">
        ${[40,80,120,160].map(x=>`<line x1="${x}" y1="40" x2="${x+16}" y2="90" stroke="#3f9eff" stroke-width="4" stroke-linecap="round"/>`).join('')}
      </g>
      <g style="opacity:0.35">
        ${[40,80,120,160].map(x=>`<line x1="${x}" y1="50" x2="${x-6}" y2="90" stroke="#7c8590" stroke-width="4" stroke-linecap="round"/>`).join('')}
      </g>
      <text x="110" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">VSV — ZMIANA KĄTA USTAWIENIA</text>
    </svg>`;
  },

  /* Surge — odwrócony przepływ */
  surge(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <rect x="20" y="40" width="180" height="50" rx="8" fill="none" stroke="#333a44"/>
      <line class="flow-line" x1="190" y1="55" x2="30" y2="55" stroke="#ff5252" stroke-width="2.5"/>
      <path d="M38 49 L24 55 L38 61 Z" fill="#ff5252"/>
      <line class="flow-line" x1="190" y1="75" x2="30" y2="75" stroke="#ff5252" stroke-width="2.5"/>
      <path d="M38 69 L24 75 L38 81 Z" fill="#ff5252"/>
      <text x="110" y="120" text-anchor="middle" fill="#ff5252" font-family="JetBrains Mono" font-size="9">POMPAŻ — ODWRÓCONY PRZEPŁYW</text>
    </svg>`;
  },

  /* Stall — lokalne oderwanie strug */
  stall(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <path d="M20 90 Q60 40 100 90" fill="none" stroke="#333a44" stroke-width="6" stroke-linecap="round"/>
      <path class="flow-line" d="M15 70 Q50 55 90 75" fill="none" stroke="#3f9eff" stroke-width="2"/>
      <g class="spark-bolt">
        <circle cx="120" cy="60" r="5" fill="#ffc636"/>
        <circle cx="135" cy="75" r="4" fill="#ffc636"/>
        <circle cx="115" cy="85" r="4" fill="#ffc636"/>
      </g>
      <text x="110" y="130" text-anchor="middle" fill="#ffc636" font-family="JetBrains Mono" font-size="9">STALL — ODERWANIE STRUG</text>
    </svg>`;
  },

  /* Oblodzenie */
  ice(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <path d="M20 90 Q110 30 200 90" fill="none" stroke="#333a44" stroke-width="8" stroke-linecap="round"/>
      <g fill="#3f9eff" opacity="0.85" class="spark-bolt">
        <path d="M40 82 l6 -10 l6 10 z"/>
        <path d="M70 68 l6 -10 l6 10 z"/>
        <path d="M100 58 l6 -10 l6 10 z"/>
        <path d="M130 62 l6 -10 l6 10 z"/>
      </g>
      <text x="110" y="130" text-anchor="middle" fill="#3f9eff" font-family="JetBrains Mono" font-size="9">NARASTANIE LODU NA KRAWĘDZI WLOTU</text>
    </svg>`;
  },

  /* Pełzanie (creep) — wydłużenie łopatki */
  creep(){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <rect x="95" y="30" width="30" height="50" fill="#242a32" stroke="#7c8590" stroke-width="1.5"/>
      <rect class="spark-bolt" x="98" y="76" width="24" height="10" fill="#ff6a1f" opacity="0.6"/>
      <line x1="60" y1="30" x2="60" y2="90" stroke="#333a44" stroke-dasharray="3 3"/>
      <line x1="160" y1="30" x2="160" y2="90" stroke="#333a44" stroke-dasharray="3 3"/>
      <text x="110" y="120" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">CREEP — TRWAŁE WYDŁUŻENIE ŁOPATKI</text>
    </svg>`;
  },

  /* Generyczny wykres domyślny (fallback) */
  generic(label){
    return `
    <svg width="220" height="150" viewBox="0 0 220 150">
      <circle cx="110" cy="65" r="40" fill="none" stroke="#333a44" stroke-width="1.5" stroke-dasharray="4 4"/>
      <circle class="spark-glow" cx="110" cy="65" r="8" fill="#ff6a1f"/>
      <text x="110" y="130" text-anchor="middle" fill="#7c8590" font-family="JetBrains Mono" font-size="9">${label}</text>
    </svg>`;
  }
};

/* Mapowanie tematu -> diagram + etykieta */
const TOPIC_DIAGRAM_MAP = {
  '1-1': () => Diagrams.thrust(),
  '2-1': () => Diagrams.airflow(),
  '2-2': () => Diagrams.rotorSpin('WENTYLATOR — OBROTY N1'),
  '2-3': () => Diagrams.rotorSpin('KOMPRESOR OSIOWY — STOPNIE'),
  '3-1': () => Diagrams.combustion(),
  '3-2': () => Diagrams.rotorSpin('TURBINA — ODZYSK ENERGII'),
  '3-3': () => Diagrams.airflow(),
  '4-1': () => Diagrams.stall(),
  '4-2': () => Diagrams.surge(),
  '4-3': () => Diagrams.rotorSpin('NIEWYWAŻENIE — DRGANIA'),
  '4-4': () => Diagrams.ice(),
  '4-5': () => Diagrams.combustion(),
  '4-6': () => Diagrams.creep(),
  '4-7': () => Diagrams.oilFlow(),
  '5-1': () => Diagrams.oilFlow(),
  '5-2': () => Diagrams.fuelFlow(),
  '5-3': () => Diagrams.rotorSpin('ROZRUCH — WIRNIK NAPĘDZANY'),
  '5-4': () => Diagrams.ignition(),
  '5-5': () => Diagrams.generic('FADEC — STEROWANIE CYFROWE')
};

function renderTopicDiagram(topicId){
  const fn = TOPIC_DIAGRAM_MAP[topicId];
  return fn ? fn() : Diagrams.generic('SCHEMAT POGLĄDOWY');
}
