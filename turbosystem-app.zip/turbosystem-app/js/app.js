/* ============================================================
   APP.JS
   Główny moduł aplikacji: ładowanie danych, renderowanie
   dashboardu, rozdziałów, słownika, fiszek, statystyk i ustawień.
============================================================ */

let CHAPTERS_DATA = null;
let QUESTIONS_DATA = null;
let GLOSSARY_DATA = null;

const ICONS = {
  flame:'<path d="M12 2C8 2 6 6 6 9c0 3 2 4 2 7a4 4 0 008 0c0-3 2-4 2-7 0-3-2-7-6-7z"/>',
  wind:'<path d="M3 8h11a3 3 0 100-6 3 3 0 00-3 3M3 16h14a3 3 0 110 6 3 3 0 01-3-3M3 12h9"/>',
  fire:'<path d="M8.5 14.5A2.5 2.5 0 0011 17a2.5 2.5 0 002.5-2.5c0-1.38-1-2-1-3.5 0 0 1.5.5 2 2.5.5-1 .5-3-1-4.5-1.5-1.5-2-4-2-4s-1 2-3 4c-1.5 1.5-2.5 3-2.5 5 0 1 .5 2 2.5 2.5z"/>',
  alert:'<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/>',
  cpu:'<rect x="7" y="7" width="10" height="10" rx="1"/><path d="M7 2v3M17 2v3M7 19v3M17 19v3M2 7h3M2 17h3M19 7h3M19 17h3"/>'
};
function lockSvg(){ return '<svg class="lock-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/></svg>'; }
function checkSvg(){ return '<svg class="lock-glyph" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6L9 17l-5-5"/></svg>'; }

const App = {

  currentChapterId: null,
  currentTopicIndex: 0,
  flashIndex: 0,
  flashDeck: [],

  /* ---------- BOOTSTRAP ---------- */
  async init(){
    try {
      const [ch, qs, gl] = await Promise.all([
        fetch('data/chapters.json').then(r => { if(!r.ok) throw new Error('fetch failed'); return r.json(); }),
        fetch('data/questions.json').then(r => { if(!r.ok) throw new Error('fetch failed'); return r.json(); }),
        fetch('data/glossary.json').then(r => { if(!r.ok) throw new Error('fetch failed'); return r.json(); })
      ]);
      CHAPTERS_DATA = ch; QUESTIONS_DATA = qs; GLOSSARY_DATA = gl;
    } catch(err){
      this.showFetchError();
      return;
    }

    Navigation.init();
    this.renderDashboard();
    this.renderChaptersScreen();
    this.renderGlossaryScreen(GLOSSARY_DATA.glossary);
    this.applySettingsUI();
    this.initBus();

    const boot = document.getElementById('boot-loader');
    setTimeout(() => boot.classList.add('hidden'), 400);

    const lastScreen = Storage.getLastScreen();
    Navigation.goTo(lastScreen, { silent:true });
  },

  showFetchError(){
    const boot = document.getElementById('boot-loader');
    boot.innerHTML = `
      <div style="max-width:300px; text-align:center; padding:0 20px;">
        <div class="boot-label" style="color:#ff5252; font-size:12px; letter-spacing:1px; line-height:1.6;">
          BŁĄD ŁADOWANIA DANYCH<br><br>
          Aplikacja wykorzystuje fetch() do wczytania plików z folderu /data.<br><br>
          Otwórz projekt przez lokalny serwer HTTP, np.:<br>
          <span style="color:#c3c9d1;">npx serve .</span><br>
          lub<br>
          <span style="color:#c3c9d1;">python -m http.server</span>
        </div>
      </div>`;
  },

  /* ---------- DASHBOARD ---------- */
  renderDashboard(){
    const progress = Storage.getProgress();
    const chapters = CHAPTERS_DATA.chapters;

    // overall completion
    const overallPct = Math.round(
      chapters.reduce((sum, ch) => sum + (progress[ch.id]?.pct || 0), 0) / chapters.length
    );
    this.updateBus(overallPct);

    const results = Storage.getResults();
    const lastResult = results[results.length - 1];
    const studySec = Storage.getStudySeconds();
    const h = Math.floor(studySec/3600), m = Math.floor((studySec%3600)/60);

    document.getElementById('stat-current-chapter').innerHTML = `${this.getCurrentChapterId(progress)}<small>/${chapters.length}</small>`;
    document.getElementById('stat-study-time').textContent = studySec > 0 ? `${h}h ${m}m` : '0h 0m';
    document.getElementById('stat-last-quiz').innerHTML = lastResult ? `${lastResult.score}<small>%</small>` : `—`;
    document.getElementById('stat-quiz-count').textContent = results.length;

    // dashboard chapter list = ostatnie 3 (lub aktywne)
    const dashList = document.getElementById('dashboard-chapters');
    dashList.innerHTML = chapters.map(ch => this.renderChapterCard(ch, progress)).join('');

    // continue button
    const activeChapter = chapters.find(ch => progress[ch.id]?.status === 'unlocked') || chapters[0];
    const continueBtn = document.getElementById('continue-btn');
    continueBtn.querySelector('.continue-label').textContent =
      `Kontynuuj naukę — Rozdz. ${activeChapter.id}: ${activeChapter.title}`;
    continueBtn.onclick = () => this.openChapter(activeChapter.id, 0);
  },

  getCurrentChapterId(progress){
    const chapters = CHAPTERS_DATA.chapters;
    const active = chapters.find(ch => progress[ch.id]?.status === 'unlocked');
    return active ? active.id : chapters[chapters.length-1].id;
  },

  initBus(){
    const track = document.getElementById('bus-track');
    const segCount = 20;
    track.innerHTML = Array.from({length:segCount}, (_,i)=>`<div class="bus-seg" data-i="${i}"></div>`).join('');
  },
  updateBus(pct){
    const segCount = 20;
    const litCount = Math.round(segCount * pct/100);
    document.querySelectorAll('.bus-seg').forEach((seg,i)=>{
      setTimeout(()=>{ seg.classList.toggle('lit', i < litCount); }, i*25);
    });
    document.getElementById('bus-pct').textContent = `${pct}% ukończono`;
    document.getElementById('voltage-readout').innerHTML = `${(14 + pct*0.14).toFixed(1)}<sup>V</sup>`;
  },

  /* ---------- CHAPTER CARDS ---------- */
  statusLabel(s){ return {locked:'ZABLOKOWANY', unlocked:'W TRAKCIE', completed:'UKOŃCZONY'}[s]; },

  renderChapterCard(ch, progress){
    const state = progress[ch.id] || {status:'locked', pct:0};
    const badgeIcon = state.status === 'locked' ? lockSvg() : state.status === 'completed' ? checkSvg() : '';
    const clickable = state.status !== 'locked';
    return `
    <div class="ch-card ${state.status}" ${clickable ? `onclick="App.openChapter(${ch.id},0)"` : ''}>
      <span class="ch-num">R${String(ch.id).padStart(2,'0')}</span>
      <div class="ch-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${ICONS[ch.icon]}</svg></div>
      <div class="ch-body">
        <div class="ch-title">${ch.title}</div>
        <div class="ch-desc">${ch.shortDesc}</div>
        <div class="ch-progress-row">
          <div class="ch-progress-track"><div class="ch-progress-fill" style="width:${state.pct||0}%;"></div></div>
          <span class="ch-progress-pct">${state.pct||0}%</span>
        </div>
        <span class="ch-status-badge">${badgeIcon} ${this.statusLabel(state.status)}</span>
      </div>
    </div>`;
  },

  renderChaptersScreen(){
    const progress = Storage.getProgress();
    document.getElementById('full-chapters').innerHTML =
      CHAPTERS_DATA.chapters.map(ch => this.renderChapterCard(ch, progress)).join('');
  },

  /* ---------- CHAPTER DETAIL ---------- */
  openChapter(chapterId, topicIndex){
    const progress = Storage.getProgress();
    if(progress[chapterId]?.status === 'locked'){
      showToast('Ten rozdział jest zablokowany 🔒');
      return;
    }
    this.currentChapterId = chapterId;
    this.currentTopicIndex = topicIndex || 0;
    this.renderChapterHero();
    this.renderTopic();
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-chapter-detail').classList.add('active');
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    window.scrollTo(0,0);
  },

  renderChapterHero(){
    const ch = CHAPTERS_DATA.chapters.find(c => c.id === this.currentChapterId);
    document.getElementById('ch-hero-eyebrow').textContent = `Rozdział ${ch.id} // ${ch.title}`;
    document.getElementById('ch-hero-title').textContent = ch.title;
    document.getElementById('topic-pills').innerHTML = ch.topics.map((t,i)=>`
      <div class="topic-pill ${i===this.currentTopicIndex?'active':''}" onclick="App.setTopic(${i})">${t.title}</div>
    `).join('');
  },

  setTopic(i){
    this.currentTopicIndex = i;
    document.querySelectorAll('.topic-pill').forEach((p,idx)=>p.classList.toggle('active', idx===i));
    this.renderTopic();
    document.getElementById('topic-block').scrollIntoView({behavior:'smooth', block:'start'});
  },

  renderTopic(){
    const ch = CHAPTERS_DATA.chapters.find(c => c.id === this.currentChapterId);
    const topic = ch.topics[this.currentTopicIndex];
    const s = topic.sections;

    document.getElementById('topic-title').textContent = topic.title;
    document.getElementById('topic-intro').textContent = topic.intro;
    document.getElementById('diagram-stage').innerHTML = renderTopicDiagram(topic.id);

    const materialsHtml = Array.isArray(s.materialy)
      ? `<div>${s.materialy.map(m=>`<span class="tag-mat">${escapeHtml(m)}</span>`).join('')}</div>`
      : `<p>${escapeHtml(s.materialy)}</p>`;

    const accItems = [
      {key:'jakDziala', title:'Jak działa', icon:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>', body:`<div class="acc-body-inner">${escapeHtml(s.jakDziala)}</div>`},
      {key:'budowa', title:'Budowa', icon:'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M10 4v16"/>', body:`<div class="acc-body-inner">${escapeHtml(s.budowa)}</div>`},
      {key:'materialy', title:'Materiały', icon:'<path d="M12 2l3 7h7l-5.5 4.5L18.5 21 12 16.5 5.5 21 7.5 13.5 2 9h7z"/>', body:`<div class="acc-body-inner">${materialsHtml}</div>`},
      {key:'usterki', title:'Najczęstsze uszkodzenia', icon:'<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/>', body:`<div class="acc-body-inner">${escapeHtml(s.usterki)}</div>`},
      {key:'ciekawostki', title:'Ciekawostki', icon:'<path d="M12 2C8 2 6 6 6 9c0 3 2 4 2 7a4 4 0 008 0c0-3 2-4 2-7 0-3-2-7-6-7z"/>', body:`<div class="acc-body-inner">${escapeHtml(s.ciekawostki)}</div>`},
      {key:'najwazniejsze', title:'Najważniejsze informacje', icon:'<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>', body:`<div class="acc-body-inner">${escapeHtml(s.najwazniejsze)}</div>`},
      {key:'podsumowanie', title:'Podsumowanie', icon:'<path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/>', body:`<div class="acc-body-inner">${escapeHtml(s.podsumowanie)}</div>`}
    ];

    document.getElementById('info-accordion').innerHTML = accItems.map((it,idx)=>`
      <div class="acc-item ${idx===0?'open':''}">
        <div class="acc-head" onclick="toggleAcc(this)">
          <div class="acc-title-wrap">
            <svg class="acc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${it.icon}</svg>
            <span class="acc-title">${it.title}</span>
          </div>
          <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>
        </div>
        <div class="acc-body">${it.body}</div>
      </div>
    `).join('');

    document.getElementById('quiz-cta-btn').onclick = () => Quiz.openSetup(this.currentChapterId);

    // flashcard preview (pojedyncza karta na dole tematu = skrót)
    this.renderTopicFlashcard(topic);
  },

  renderTopicFlashcard(topic){
    document.getElementById('topic-flashcard').innerHTML = `
      <div class="flashcard" onclick="this.classList.toggle('flipped')">
        <div class="flashcard-inner">
          <div class="flash-face flash-front">
            <div class="term">${escapeHtml(topic.title)}</div>
            <div class="hint">dotknij, aby odwrócić</div>
          </div>
          <div class="flash-face flash-back">
            <p>${escapeHtml(topic.sections.podsumowanie)}</p>
          </div>
        </div>
      </div>`;
  },

  /* ---------- FLASHCARDS SCREEN (pełna talia dla rozdziału) ---------- */
  openFlashDeck(chapterId){
    const ch = CHAPTERS_DATA.chapters.find(c => c.id === chapterId);
    this.flashDeck = ch.topics.map(t => ({ term: t.title, def: t.sections.podsumowanie }));
    this.flashIndex = 0;
    document.getElementById('flash-chapter-title').textContent = `Fiszki // ${ch.title}`;
    this.renderFlashcard();
    Navigation.goTo('flashcards');
  },
  renderFlashcard(){
    const card = this.flashDeck[this.flashIndex];
    document.getElementById('flash-progress').textContent = `${this.flashIndex+1} / ${this.flashDeck.length}`;
    document.getElementById('flash-container').innerHTML = `
      <div class="flashcard" onclick="this.classList.toggle('flipped')">
        <div class="flashcard-inner">
          <div class="flash-face flash-front">
            <div class="term">${escapeHtml(card.term)}</div>
            <div class="hint">dotknij, aby odwrócić</div>
          </div>
          <div class="flash-face flash-back"><p>${escapeHtml(card.def)}</p></div>
        </div>
      </div>`;
  },
  flashNext(){ if(this.flashIndex < this.flashDeck.length-1){ this.flashIndex++; this.renderFlashcard(); } },
  flashPrev(){ if(this.flashIndex > 0){ this.flashIndex--; this.renderFlashcard(); } },

  /* ---------- GLOSSARY ---------- */
  renderGlossaryScreen(list){
    document.getElementById('glossary-list').innerHTML = list.map(g=>`
      <div class="gloss-row"><span class="gterm">${escapeHtml(g.term)}</span><span class="gdef">${escapeHtml(g.def)}</span></div>
    `).join('');
  },
  filterGlossary(q){
    q = q.toLowerCase();
    const filtered = GLOSSARY_DATA.glossary.filter(g =>
      g.term.toLowerCase().includes(q) || g.def.toLowerCase().includes(q)
    );
    this.renderGlossaryScreen(filtered);
  },

  /* ---------- SEARCH (dashboard/chapters) ---------- */
  globalSearch(query){
    const resultsEl = document.getElementById('search-results');
    const countEl = document.getElementById('search-results-count');
    if(!query || query.trim().length < 2){
      resultsEl.innerHTML = '';
      countEl.textContent = '';
      return;
    }
    const q = query.toLowerCase();
    const hits = [];

    CHAPTERS_DATA.chapters.forEach(ch => {
      ch.topics.forEach(topic => {
        const haystack = JSON.stringify(topic).toLowerCase();
        if(haystack.includes(q)){
          hits.push({ chapter: ch.id, chapterTitle: ch.title, title: topic.title, snippet: topic.intro });
        }
      });
    });
    GLOSSARY_DATA.glossary.forEach(g => {
      if(g.term.toLowerCase().includes(q) || g.def.toLowerCase().includes(q)){
        hits.push({ chapter: g.chapter, chapterTitle: 'Słownik', title: g.term, snippet: g.def });
      }
    });

    countEl.textContent = `${hits.length} wyników dla "${query}"`;
    resultsEl.innerHTML = hits.map(h => `
      <div class="search-hit">
        <div class="sh-chapter">ROZDZ. ${h.chapter} // ${escapeHtml(h.chapterTitle)}</div>
        <div class="sh-title">${escapeHtml(h.title)}</div>
        <div class="sh-snippet">${escapeHtml(h.snippet)}</div>
      </div>
    `).join('') || `<p class="lead" style="margin-top:14px;">Brak wyników.</p>`;
  },

  /* ---------- STATS ---------- */
  renderStats(){
    const stats = Storage.computeStats();
    document.getElementById('stat-best').textContent = stats.count ? stats.best + '%' : '—';
    document.getElementById('stat-avg').textContent = stats.count ? stats.avg + '%' : '—';

    const barChart = document.getElementById('bar-chart');
    if(stats.count === 0){
      barChart.parentElement.style.display = 'none';
    } else {
      barChart.parentElement.style.display = '';
      barChart.innerHTML = CHAPTERS_DATA.chapters.map(ch => {
        const scores = stats.byChapter?.[ch.id];
        const avg = scores ? Math.round(scores.reduce((s,v)=>s+v,0)/scores.length) : null;
        const color = avg===null ? '#242a32' : avg>=85 ? 'var(--green)' : avg>=70 ? 'var(--blue)' : avg>=50 ? 'var(--yellow)' : 'var(--red)';
        return `<div class="bar-row">
          <span class="bar-label">${ch.id}. ${ch.title}</span>
          <div class="bar-track"><div class="bar-fill" style="width:${avg||0}%; background:${color};"></div></div>
          <span class="bar-val">${avg!==null ? avg+'%' : '—'}</span>
        </div>`;
      }).join('');
    }

    const mistakeList = document.getElementById('mistake-list');
    const mistakeEntries = Object.entries(stats.mistakeFreq || {}).sort((a,b)=>b[1]-a[1]).slice(0,6);
    document.getElementById('mistakes-section').style.display = mistakeEntries.length ? '' : 'none';
    mistakeList.innerHTML = mistakeEntries.map(([q,count]) => `
      <div class="mistake-row"><span class="mterm">${escapeHtml(q.length>46?q.slice(0,46)+'…':q)}</span><span class="mcount">×${count}</span></div>
    `).join('');

    const hardestEl = document.getElementById('hardest-chapter');
    if(stats.hardestChapter){
      const ch = CHAPTERS_DATA.chapters.find(c=>c.id===stats.hardestChapter);
      hardestEl.innerHTML = `Najtrudniejszy rozdział: <span style="color:var(--red);">${ch.id} — ${ch.title}</span>`;
      hardestEl.style.display = '';
    } else {
      hardestEl.style.display = 'none';
    }

    document.getElementById('stats-empty').style.display = stats.count ? 'none' : '';
  },

  /* ---------- SETTINGS ---------- */
  applySettingsUI(){
    const s = Storage.getSettings();
    document.getElementById('toggle-dark').classList.toggle('on', s.darkMode);
    document.getElementById('toggle-sound').classList.toggle('on', s.sound);
    document.getElementById('toggle-offline').classList.toggle('on', s.offline);
  },
  toggleSetting(key, el){
    const s = Storage.getSettings();
    s[key] = !s[key];
    Storage.saveSettings(s);
    el.classList.toggle('on', s[key]);
    showToast(s[key] ? 'Włączono' : 'Wyłączono');
  },
  confirmReset(){
    document.getElementById('reset-modal').classList.add('show');
  },
  closeResetModal(){
    document.getElementById('reset-modal').classList.remove('show');
  },
  performReset(){
    Storage.resetAll();
    this.closeResetModal();
    showToast('Postęp zresetowany');
    setTimeout(() => location.reload(), 800);
  },
  exportResults(){
    const results = Storage.getResults();
    if(results.length === 0){
      showToast('Brak wyników do wyeksportowania');
      return;
    }
    Storage.exportResultsAsFile();
    showToast('Wyniki wyeksportowane (JSON)');
  }
};

/* accordion toggle (globalna funkcja używana w markupie) */
function toggleAcc(head){
  const item = head.closest('.acc-item');
  const wasOpen = item.classList.contains('open');
  item.parentElement.querySelectorAll('.acc-item').forEach(i => i.classList.remove('open'));
  if(!wasOpen) item.classList.add('open');
}

document.addEventListener('DOMContentLoaded', () => App.init());
